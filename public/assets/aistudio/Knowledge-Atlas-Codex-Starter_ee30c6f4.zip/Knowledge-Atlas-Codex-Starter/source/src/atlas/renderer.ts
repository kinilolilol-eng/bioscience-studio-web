import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { visualBridgeProposals, visualWeakTransitions } from "./discovery";
import { AtlasModel, AtlasMode, AtlasSelection } from "./types";

interface AtlasRendererOptions {
	onSelect: (nodeId: string | null) => void;
	onInsight: (kind: "bridge" | "gap", id: string) => void;
	onHover: (nodeId: string | null, point: { x: number; y: number } | null) => void;
	onOpen: (nodeId: string) => void;
}

interface NodeVisual {
	mesh: THREE.Mesh<THREE.SphereGeometry, THREE.MeshStandardMaterial>;
	nodeId: string;
	baseColor: THREE.Color;
	baseScale: number;
}

interface EdgeVisual {
	line: THREE.Line<THREE.BufferGeometry, THREE.LineBasicMaterial | THREE.LineDashedMaterial>;
	edgeId: string;
	source: string;
	target: string;
	kind: "declared" | "working" | "bridge" | "gap" | "pattern" | "path";
}

type PickResult = { kind: "node"; id: string } | { kind: "bridge" | "gap"; id: string };

export class AtlasRenderer {
	private readonly scene = new THREE.Scene();
	private readonly camera = new THREE.PerspectiveCamera(44, 1, 0.1, 1000);
	private readonly renderer: THREE.WebGLRenderer;
	private readonly controls: OrbitControls;
	private readonly raycaster = new THREE.Raycaster();
	private readonly pointer = new THREE.Vector2();
	private readonly nodesGroup = new THREE.Group();
	private readonly edgesGroup = new THREE.Group();
	private readonly nodeVisuals = new Map<string, NodeVisual>();
	private readonly edgeVisuals: EdgeVisual[] = [];
	private readonly resizeObserver: ResizeObserver;
	private animationFrame = 0;
	private model: AtlasModel | null = null;
	private selection: AtlasSelection | null = null;
	private activeTopics = new Set<string>();
	private mode: AtlasMode = "atlas";
	private focusedProposalId: string | null = null;
	private focusedGapId: string | null = null;
	private activePatternId: string | null = null;
	private pathNodeIds: string[] = [];
	private pathEdgeIds = new Set<string>();
	private pointerDown = { x: 0, y: 0, time: 0 };
	private lastClick = { nodeId: "", time: 0 };
	private readonly reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

	constructor(private readonly container: HTMLElement, private readonly options: AtlasRendererOptions) {
		this.raycaster.params.Line = { threshold: 0.55 };
		this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
		this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
		this.renderer.setClearColor(0x080b12, 1);
		this.renderer.outputColorSpace = THREE.SRGBColorSpace;
		this.renderer.domElement.className = "elf-atlas-canvas";
		this.renderer.domElement.tabIndex = 0;
		this.renderer.domElement.setAttribute("role", "application");
		this.renderer.domElement.setAttribute("aria-label", "Interactive three-dimensional personal concept atlas. Use drag to orbit, right-drag to pan, and scroll to zoom.");
		container.appendChild(this.renderer.domElement);

		this.scene.fog = new THREE.FogExp2(0x080b12, 0.0105);
		this.scene.add(this.nodesGroup, this.edgesGroup);
		this.scene.add(new THREE.HemisphereLight(0xbfd8ff, 0x10131c, 1.3));
		const key = new THREE.DirectionalLight(0xffffff, 1.1);
		key.position.set(20, 36, 24);
		this.scene.add(key);

		this.camera.position.set(0, 26, 74);
		this.controls = new OrbitControls(this.camera, this.renderer.domElement);
		this.controls.enableDamping = true;
		this.controls.dampingFactor = 0.055;
		this.controls.rotateSpeed = 0.48;
		this.controls.zoomSpeed = 0.72;
		this.controls.panSpeed = 0.6;
		this.controls.minDistance = 12;
		this.controls.maxDistance = 190;
		this.controls.autoRotate = !this.reduceMotion;
		this.controls.autoRotateSpeed = 0.26;
		this.controls.addEventListener("start", () => { this.controls.autoRotate = false; });

		this.renderer.domElement.addEventListener("pointerdown", this.onPointerDown);
		this.renderer.domElement.addEventListener("pointermove", this.onPointerMove);
		this.renderer.domElement.addEventListener("pointerup", this.onPointerUp);
		this.renderer.domElement.addEventListener("pointerleave", this.onPointerLeave);
		this.resizeObserver = new ResizeObserver(() => this.resize());
		this.resizeObserver.observe(container);
		this.resize();
		this.animate();
	}

	setModel(model: AtlasModel): void {
		this.model = model;
		this.activeTopics = new Set(model.topics.map((topic) => topic.id));
		this.selection = null;
		this.rebuildScene();
		this.frameAll();
	}

	setMode(mode: AtlasMode): void {
		this.mode = mode;
		this.focusedProposalId = null;
		this.focusedGapId = null;
		if (mode !== "patterns") this.activePatternId = null;
		this.rebuildEdges();
		this.applyVisualState();
	}

	setFocusedProposal(proposalId: string | null): void {
		this.focusedProposalId = proposalId;
		this.focusedGapId = null;
		this.applyVisualState();
		const proposal = this.model?.proposals.find((candidate) => candidate.id === proposalId);
		if (proposal) this.focusPair(proposal.source, proposal.target);
	}

	setFocusedGap(edgeId: string | null): void {
		this.focusedGapId = edgeId;
		this.focusedProposalId = null;
		this.applyVisualState();
		const transition = this.model?.weakTransitions.find((candidate) => candidate.edgeId === edgeId);
		if (transition) this.focusPair(transition.source, transition.target);
	}

	setPattern(patternId: string | null): void {
		this.activePatternId = patternId;
		this.rebuildEdges();
		this.applyVisualState();
		const pattern = this.model?.patterns.find((candidate) => candidate.id === patternId);
		const first = pattern?.instances[0];
		if (first?.length) this.frameNodes(first);
	}

	setPath(nodeIds: string[] | null): void {
		this.pathNodeIds = nodeIds ? [...nodeIds] : [];
		this.pathEdgeIds.clear();
		if (this.model && nodeIds) {
			for (let index = 0; index < nodeIds.length - 1; index += 1) {
				const pair = new Set([nodeIds[index], nodeIds[index + 1]]);
				const edge = this.model.edges.find((candidate) => pair.has(candidate.source) && pair.has(candidate.target));
				if (edge) this.pathEdgeIds.add(edge.id);
			}
		}
		this.rebuildEdges();
		this.applyVisualState();
		if (nodeIds?.length) this.frameNodes(nodeIds);
	}

	setActiveTopics(topics: Set<string>): void {
		this.activeTopics = new Set(topics);
		this.applyVisualState();
	}

	setSelection(selection: AtlasSelection | null): void {
		this.selection = selection;
		this.controls.autoRotate = !selection && !this.reduceMotion;
		if (this.mode === "bridges" || this.mode === "gaps") this.rebuildEdges();
		this.applyVisualState();
		if (selection) this.focusNode(selection.selectedId);
	}

	focusNode(nodeId: string): void {
		const visual = this.nodeVisuals.get(nodeId);
		if (!visual) return;
		const target = visual.mesh.position.clone();
		const offset = this.camera.position.clone().sub(this.controls.target).normalize().multiplyScalar(25);
		this.controls.target.copy(target);
		this.camera.position.copy(target.clone().add(offset).add(new THREE.Vector3(0, 5, 0)));
		this.controls.update();
	}

	focusNodes(nodeIds: string[]): void {
		this.frameNodes(nodeIds);
	}

	private focusPair(sourceId: string, targetId: string): void {
		this.frameNodes([sourceId, targetId], 30);
	}

	private frameNodes(nodeIds: string[], minimumDistance = 28): void {
		const points = nodeIds.map((id) => this.nodeVisuals.get(id)?.mesh.position).filter((point): point is THREE.Vector3 => Boolean(point));
		if (!points.length) return;
		const box = new THREE.Box3();
		for (const point of points) box.expandByPoint(point);
		const center = box.getCenter(new THREE.Vector3());
		const size = box.getSize(new THREE.Vector3());
		const distance = Math.max(minimumDistance, size.length() * 1.15);
		const direction = this.camera.position.clone().sub(this.controls.target).normalize();
		this.controls.target.copy(center);
		this.camera.position.copy(center.clone().add(direction.multiplyScalar(distance)).add(new THREE.Vector3(0, 3, 0)));
		this.controls.update();
	}

	frameAll(): void {
		if (!this.model?.nodes.length) return;
		const box = new THREE.Box3();
		for (const visual of this.nodeVisuals.values()) box.expandByPoint(visual.mesh.position);
		const center = box.getCenter(new THREE.Vector3());
		const size = box.getSize(new THREE.Vector3());
		const distance = Math.max(42, size.length() * 0.78);
		this.controls.target.copy(center);
		this.camera.position.set(center.x + distance * 0.12, center.y + distance * 0.32, center.z + distance);
		this.camera.near = Math.max(0.1, distance / 1000);
		this.camera.far = distance * 10;
		this.camera.updateProjectionMatrix();
		this.controls.update();
	}

	dispose(): void {
		cancelAnimationFrame(this.animationFrame);
		this.resizeObserver.disconnect();
		this.renderer.domElement.removeEventListener("pointerdown", this.onPointerDown);
		this.renderer.domElement.removeEventListener("pointermove", this.onPointerMove);
		this.renderer.domElement.removeEventListener("pointerup", this.onPointerUp);
		this.renderer.domElement.removeEventListener("pointerleave", this.onPointerLeave);
		this.clearScene();
		this.controls.dispose();
		this.renderer.dispose();
		this.renderer.domElement.remove();
	}

	private rebuildScene(): void {
		this.clearScene();
		if (!this.model) return;
		const topicColors = new Map(this.model.topics.map((topic) => [topic.id, new THREE.Color(topic.color)]));
		for (const node of this.model.nodes) {
			const baseScale = 0.55 + Math.min(0.65, node.centrality * 0.8);
			const geometry = new THREE.SphereGeometry(baseScale, 18, 14);
			const color = topicColors.get(node.topic) ?? new THREE.Color("#9fb4cc");
			const material = new THREE.MeshStandardMaterial({
				color,
				emissive: color.clone().multiplyScalar(0.12),
				roughness: 0.36,
				metalness: 0.06,
				transparent: true,
				opacity: 0.9,
				depthWrite: true,
			});
			const mesh = new THREE.Mesh(geometry, material);
			mesh.position.set(node.position.x, node.position.y, node.position.z);
			mesh.userData.nodeId = node.id;
			this.nodesGroup.add(mesh);
			this.nodeVisuals.set(node.id, { mesh, nodeId: node.id, baseColor: color.clone(), baseScale });
		}
		this.rebuildEdges();
		this.applyVisualState();
	}

	private rebuildEdges(): void {
		for (const visual of this.edgeVisuals) {
			visual.line.geometry.dispose();
			visual.line.material.dispose();
			this.edgesGroup.remove(visual.line);
		}
		this.edgeVisuals.length = 0;
		if (!this.model) return;
		const selectedId = this.selection?.selectedId ?? null;
		const weakIds = new Set(this.mode === "gaps" ? visualWeakTransitions(this.model, selectedId).map((transition) => transition.edgeId) : []);
		const pattern = this.mode === "patterns" ? this.model.patterns.find((candidate) => candidate.id === this.activePatternId) : null;
		const patternIds = new Set<string>();
		if (pattern) {
			for (const instance of pattern.instances) {
				for (let index = 0; index < instance.length - 1; index += 1) {
					const pair = new Set([instance[index], instance[index + 1]]);
					const edge = this.model.edges.find((candidate) => pair.has(candidate.source) && pair.has(candidate.target));
					if (edge) patternIds.add(edge.id);
				}
			}
		}
		for (const edge of this.model.edges) {
			const kind = this.pathEdgeIds.has(edge.id) ? "path"
				: patternIds.has(edge.id) ? "pattern"
					: weakIds.has(edge.id) ? "gap" : "declared";
			this.addEdge(edge.id, edge.source, edge.target, kind);
		}
		if (this.mode === "bridges") {
			for (const proposal of visualBridgeProposals(this.model, selectedId)) this.addEdge(proposal.id, proposal.source, proposal.target, "bridge");
		}
		if (this.mode === "atlas") {
			for (const proposal of this.model.proposals.filter((candidate) => candidate.reviewStatus === "named")) this.addEdge(proposal.id, proposal.source, proposal.target, "working");
		}
	}

	private addEdge(id: string, sourceId: string, targetId: string, kind: EdgeVisual["kind"]): void {
		const source = this.nodeVisuals.get(sourceId)?.mesh.position;
		const target = this.nodeVisuals.get(targetId)?.mesh.position;
		if (!source || !target) return;
		const geometry = new THREE.BufferGeometry().setFromPoints([source, target]);
		const material = kind === "bridge"
			? new THREE.LineDashedMaterial({ color: 0xc5a5ff, transparent: true, opacity: 0.32, dashSize: 0.72, gapSize: 0.48 })
			: kind === "working"
				? new THREE.LineBasicMaterial({ color: 0xc5a5ff, transparent: true, opacity: 0.36 })
			: kind === "gap"
				? new THREE.LineDashedMaterial({ color: 0xe0ad76, transparent: true, opacity: 0.55, dashSize: 0.34, gapSize: 0.28 })
				: kind === "pattern"
					? new THREE.LineBasicMaterial({ color: 0x79ccb2, transparent: true, opacity: 0.68 })
					: kind === "path"
						? new THREE.LineBasicMaterial({ color: 0xa9d4ff, transparent: true, opacity: 0.94 })
						: new THREE.LineBasicMaterial({ color: 0x8797b1, transparent: true, opacity: 0.1 });
		const line = new THREE.Line(geometry, material);
		if (kind === "bridge" || kind === "gap") line.computeLineDistances();
		line.renderOrder = kind === "declared" ? 1 : 2;
		line.userData.edgeId = id;
		line.userData.edgeKind = kind === "working" ? "bridge" : kind;
		this.edgesGroup.add(line);
		this.edgeVisuals.push({ line, edgeId: id, source: sourceId, target: targetId, kind });
	}

	private applyVisualState(): void {
		if (!this.model) return;
		const selectedId = this.selection?.selectedId ?? null;
		const focusIds = new Set<string>(selectedId ? [selectedId, ...this.selection!.ancestorIds, ...this.selection!.directNextIds] : []);
		for (const id of this.pathNodeIds) focusIds.add(id);
		const focusedProposal = this.model.proposals.find((proposal) => proposal.id === this.focusedProposalId);
		if (focusedProposal) { focusIds.add(focusedProposal.source); focusIds.add(focusedProposal.target); }
		const focusedGap = this.model.weakTransitions.find((transition) => transition.edgeId === this.focusedGapId);
		if (focusedGap) { focusIds.add(focusedGap.source); focusIds.add(focusedGap.target); }
		if (this.mode === "bridges" && !focusedProposal) {
			for (const proposal of visualBridgeProposals(this.model, selectedId)) { focusIds.add(proposal.source); focusIds.add(proposal.target); }
		}
		if (this.mode === "gaps" && !focusedGap) {
			for (const transition of visualWeakTransitions(this.model, selectedId)) { focusIds.add(transition.source); focusIds.add(transition.target); }
		}
		if (this.mode === "patterns") {
			const pattern = this.model.patterns.find((candidate) => candidate.id === this.activePatternId);
			for (const instance of pattern?.instances ?? []) for (const id of instance) focusIds.add(id);
		}
		const hasFocus = focusIds.size > 0;
		for (const node of this.model.nodes) {
			const visual = this.nodeVisuals.get(node.id);
			if (!visual) continue;
			const topicVisible = this.activeTopics.has(node.topic);
			visual.mesh.visible = topicVisible;
			if (!topicVisible) continue;
			const focused = !hasFocus || focusIds.has(node.id);
			const isSelected = node.id === selectedId;
			visual.mesh.material.color.copy(visual.baseColor);
			visual.mesh.material.emissive.copy(isSelected ? new THREE.Color(0xffffff) : visual.baseColor).multiplyScalar(isSelected ? 0.62 : 0.12);
			visual.mesh.material.opacity = isSelected ? 1 : focused ? 0.92 : 0.12;
			visual.mesh.material.depthWrite = !hasFocus || focused;
			visual.mesh.scale.setScalar(isSelected ? 1.38 : this.pathNodeIds.includes(node.id) || this.selection?.directFoundationIds.has(node.id) ? 1.14 : 1);
		}
		for (const visual of this.edgeVisuals) {
			const sourceNode = this.model.nodes.find((node) => node.id === visual.source);
			const targetNode = this.model.nodes.find((node) => node.id === visual.target);
			const topicVisible = Boolean(sourceNode && targetNode && this.activeTopics.has(sourceNode.topic) && this.activeTopics.has(targetNode.topic));
			visual.line.visible = topicVisible;
			if (!topicVisible) continue;
			const material = visual.line.material;
			if (visual.kind === "bridge") {
				const chosen = visual.edgeId === this.focusedProposalId;
				const touches = !selectedId || visual.source === selectedId || visual.target === selectedId;
				material.opacity = this.focusedProposalId ? (chosen ? 0.95 : 0.045) : touches ? 0.42 : 0.07;
				continue;
			}
			if (visual.kind === "working") {
				const touches = !selectedId || visual.source === selectedId || visual.target === selectedId;
				material.opacity = touches ? 0.52 : 0.08;
				continue;
			}
			if (visual.kind === "gap") {
				const chosen = visual.edgeId === this.focusedGapId;
				material.opacity = this.focusedGapId ? (chosen ? 0.95 : 0.05) : 0.58;
				continue;
			}
			if (visual.kind === "pattern") { material.opacity = 0.76; continue; }
			if (visual.kind === "path") { material.opacity = 0.96; continue; }
			const lineage = this.selection?.lineageEdgeIds.has(visual.edgeId) ?? false;
			material.opacity = this.mode === "atlas" ? (!selectedId ? 0.1 : lineage ? 0.88 : 0.018) : lineage ? 0.22 : 0.012;
			material.color.set(lineage ? 0x9fc9ff : 0x738198);
		}
	}

	private clearScene(): void {
		for (const visual of this.nodeVisuals.values()) {
			visual.mesh.geometry.dispose();
			visual.mesh.material.dispose();
			this.nodesGroup.remove(visual.mesh);
		}
		this.nodeVisuals.clear();
		for (const visual of this.edgeVisuals) {
			visual.line.geometry.dispose();
			visual.line.material.dispose();
			this.edgesGroup.remove(visual.line);
		}
		this.edgeVisuals.length = 0;
	}

	private resize(): void {
		const width = Math.max(1, this.container.clientWidth);
		const height = Math.max(1, this.container.clientHeight);
		this.renderer.setSize(width, height, false);
		this.camera.aspect = width / height;
		this.camera.updateProjectionMatrix();
	}

	private animate = (): void => {
		this.animationFrame = requestAnimationFrame(this.animate);
		this.controls.update();
		this.renderer.render(this.scene, this.camera);
	};

	private pick(event: PointerEvent): PickResult | null {
		const rect = this.renderer.domElement.getBoundingClientRect();
		this.pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
		this.pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
		this.raycaster.setFromCamera(this.pointer, this.camera);
		const visibleMeshes = [...this.nodeVisuals.values()].map((visual) => visual.mesh).filter((mesh) => mesh.visible);
		const nodeId = this.raycaster.intersectObjects(visibleMeshes, false)[0]?.object.userData.nodeId as string | undefined;
		if (nodeId) return { kind: "node", id: nodeId };
		const pickableLines = this.edgeVisuals
			.filter((visual) => visual.line.visible && (visual.kind === "bridge" || visual.kind === "working" || visual.kind === "gap"))
			.map((visual) => visual.line);
		const line = this.raycaster.intersectObjects(pickableLines, false)[0]?.object;
		const kind = line?.userData.edgeKind as "bridge" | "gap" | undefined;
		const id = line?.userData.edgeId as string | undefined;
		return kind && id ? { kind, id } : null;
	}

	private onPointerDown = (event: PointerEvent): void => {
		this.pointerDown = { x: event.clientX, y: event.clientY, time: performance.now() };
	};

	private onPointerMove = (event: PointerEvent): void => {
		const picked = this.pick(event);
		this.renderer.domElement.style.cursor = picked ? "pointer" : "grab";
		const nodeId = picked?.kind === "node" ? picked.id : null;
		this.options.onHover(nodeId, nodeId ? { x: event.clientX, y: event.clientY } : null);
	};

	private onPointerUp = (event: PointerEvent): void => {
		const moved = Math.hypot(event.clientX - this.pointerDown.x, event.clientY - this.pointerDown.y);
		if (moved > 5 || performance.now() - this.pointerDown.time > 600) return;
		const picked = this.pick(event);
		if (!picked) {
			this.options.onSelect(null);
			return;
		}
		if (picked.kind === "bridge" || picked.kind === "gap") {
			this.options.onInsight(picked.kind, picked.id);
			return;
		}
		const nodeId = picked.id;
		const now = performance.now();
		if (this.lastClick.nodeId === nodeId && now - this.lastClick.time < 360) this.options.onOpen(nodeId);
		else this.options.onSelect(nodeId);
		this.lastClick = { nodeId, time: now };
	};

	private onPointerLeave = (): void => {
		this.options.onHover(null, null);
	};
}
