import { Modal, Notice, Setting } from "obsidian";
import type PersonalAtlasPlugin from "../atlas-main";
import { RelationProposal } from "./types";

export class NameConnectionModal extends Modal {
	private predicate: string;
	private note: string;

	constructor(private readonly plugin: PersonalAtlasPlugin, private readonly proposal: RelationProposal) {
		super(plugin.app);
		this.predicate = proposal.workingPredicate ?? proposal.surfacePredicates[0] ?? "";
		this.note = proposal.reviewerNote ?? "";
	}

	onOpen(): void {
		this.contentEl.empty();
		this.contentEl.addClass("elf-connection-modal");
		this.contentEl.createDiv({ cls: "elf-atlas-kicker", text: "NAME THIS CONNECTION" });
		this.contentEl.createEl("h2", { text: "What relationship do you see?" });
		this.contentEl.createEl("p", { text: "Your wording becomes part of the working atlas. It can be revised later and does not edit either note." });
		new Setting(this.contentEl)
			.setName("Connection")
			.setDesc("Use a short phrase that reads naturally between the two ideas.")
			.addText((text) => text
				.setPlaceholder("e.g. reframes, depends on, is an instance of")
				.setValue(this.predicate)
				.onChange((value) => { this.predicate = value; }));
		new Setting(this.contentEl)
			.setName("Personal note")
			.setDesc("Optional: capture the boundary or reason that matters to you.")
			.addText((text) => text
				.setPlaceholder("Why this connection matters…")
				.setValue(this.note)
				.onChange((value) => { this.note = value; }));
		new Setting(this.contentEl)
			.addButton((button) => button.setButtonText("Cancel").onClick(() => this.close()))
			.addButton((button) => button.setButtonText(this.proposal.reviewStatus === "named" ? "Update connection" : "Use this connection").setCta().onClick(async () => {
				const predicate = this.predicate.trim();
				if (!predicate) {
					new Notice("Name the connection first.");
					return;
				}
				await this.plugin.reviewProposal(this.proposal.id, this.proposal.reviewStatus === "named" ? "revise" : "name", { predicate, note: this.note });
				this.close();
			}));
	}

	onClose(): void { this.contentEl.empty(); }
}
