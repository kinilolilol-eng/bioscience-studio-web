import { ItemView, Notice, TFile, WorkspaceLeaf, setIcon } from "obsidian";
import type PersonalAtlasPlugin from "../atlas-main";
import { intelligibilityPaths } from "./discovery";
import { selectionFor } from "./logic";
import { NameConnectionModal } from "./review-modal";
import { AtlasRenderer } from "./renderer";
import {
	AtlasMode,
	AtlasNode,
	AtlasPattern,
	AtlasSelection,
	IntelligibilityPath,
	RelationProposal,
	WeakTransition,
} from "./types";

export const VIEW_TYPE_ATLAS = "elf-personal-atlas";

export class PersonalAtlasView extends ItemView {
	private plugin: PersonalAtlasPlugin;
	private renderer: AtlasRenderer | null = null;
	private model: Awaited<ReturnType<PersonalAtlasPlugin["getModel"]>> | null = null;
	private selection: AtlasSelection | null = null;
	private activeTopics = new Set<string>();
	private mode: AtlasMode = "atlas";
	private selectedProposalId: string | null = null;
	private selectedGapId: string | null = null;
	private selectedPatternId: string | null = null;
	private selectedPathId: string | null = null;
	private patternInstance = 0;
	private rootEl: HTMLElement | null = null;
	private stageEl: HTMLElement | null = null;
	private cardEl: HTMLElement | null = null;
	private legendEl: HTMLElement | null = null;
	private railEl: HTMLElement | null = null;
	private searchEl: HTMLInputElement | null = null;
	private searchResultsEl: HTMLElement | null = null;
	private tooltipEl: HTMLElement | null = null;
	private emptyEl: HTMLElement | null = null;
	private loadGeneration = 0;

	constructor(leaf: WorkspaceLeaf, plugin: PersonalAtlasPlugin) {
		super(leaf);
		this.plugin = plugin;
	}

	getViewType(): string { return VIEW_TYPE_ATLAS; }
	getDisplayText(): string { return "Personal Knowledge Atlas"; }
	getIcon(): string { return "orbit"; }

	async onOpen(): Promise<void> {
		this.contentEl.empty();
		this.contentEl.addClass("elf-atlas-view");
		this.rootEl = this.contentEl.createDiv({ cls: "elf-atlas-root" });
		this.stageEl = this.rootEl.createDiv({ cls: "elf-atlas-stage" });
		this.buildChrome();
		this.renderer = new AtlasRenderer(this.stageEl, {
			onSelect: (id) => this.selectNode(id),
			onInsight: (kind, id) => this.selectInsight(kind, id),
			onHover: (id, point) => this.showTooltip(id, point),
			onOpen: (id) => void this.openNode(id),
		});
		await this.reload();
	}

	async onClose(): Promise<void> {
		this.renderer?.dispose();
		this.renderer = null;
		this.contentEl.empty();
	}

	async reload(force = true): Promise<void> {
		const generation = ++this.loadGeneration;
		const previousNodeId = this.selection?.selectedId ?? null;
		const previousProposalId = this.selectedProposalId;
		const previousGapId = this.selectedGapId;
		const previousPatternId = this.selectedPatternId;
		this.setLoading(true);
		try {
			const model = await this.plugin.getModel(force);
			if (generation !== this.loadGeneration) return;
			this.model = model;
			this.activeTopics = new Set(model.topics.map((topic) => topic.id));
			this.renderer?.setModel(model);
			this.renderer?.setMode(this.mode);
			this.renderLegend();
			this.renderLensRail();
			if (previousProposalId && model.proposals.some((proposal) => proposal.id === previousProposalId && proposal.reviewStatus !== "dismissed")) this.selectInsight("bridge", previousProposalId);
			else if (previousGapId && model.weakTransitions.some((gap) => gap.edgeId === previousGapId)) this.selectInsight("gap", previousGapId);
			else if (this.mode === "patterns" && model.patterns.length) this.selectPattern(model.patterns.some((pattern) => pattern.id === previousPatternId) ? previousPatternId! : model.patterns[0].id);
			else if (previousNodeId && model.nodes.some((node) => node.id === previousNodeId)) this.selectNode(previousNodeId);
			else this.selectNode(null);
			this.emptyEl?.toggleClass("is-visible", model.nodes.length === 0);
		} catch (error) {
			console.error("Personal Knowledge Atlas: build failed", error);
			new Notice("Personal Knowledge Atlas could not be built. See the console for details.");
		} finally {
			if (generation === this.loadGeneration) this.setLoading(false);
		}
	}

	focusConcept(nodeId: string): void {
		if (!this.model?.nodes.some((node) => node.id === nodeId)) {
			new Notice("The active note is not part of a Concept Graph.");
			return;
		}
		this.chooseSearchResult(nodeId);
	}

	private buildChrome(): void {
		if (!this.rootEl) return;
		const header = this.rootEl.createDiv({ cls: "elf-atlas-header" });
		const identity = header.createDiv({ cls: "elf-atlas-identity" });
		identity.createDiv({ cls: "elf-atlas-kicker", text: "PERSONAL KNOWLEDGE ATLAS" });
		identity.createDiv({ cls: "elf-atlas-subtitle", text: "A spatial view of how your ideas fit together" });

		const controls = header.createDiv({ cls: "elf-atlas-controls" });
		const searchWrap = controls.createDiv({ cls: "elf-atlas-search" });
		const searchIcon = searchWrap.createSpan({ cls: "elf-atlas-search-icon" });
		setIcon(searchIcon, "search");
		this.searchEl = searchWrap.createEl("input", { type: "search", placeholder: "Find an idea…", attr: { "aria-label": "Find an idea" } });
		this.searchEl.addEventListener("input", () => this.renderSearchResults());
		this.searchEl.addEventListener("keydown", (event) => {
			if (event.key === "Escape") {
				this.searchEl!.value = "";
				this.renderSearchResults();
				this.searchEl!.blur();
			}
			if (event.key === "Enter") {
				const first = this.searchMatches()[0];
				if (first) this.chooseSearchResult(first.id);
			}
		});
		this.searchResultsEl = searchWrap.createDiv({ cls: "elf-atlas-search-results", attr: { role: "listbox" } });

		const modes = controls.createDiv({ cls: "elf-atlas-mode", attr: { role: "group", "aria-label": "Atlas view" } });
		for (const [value, label] of [["atlas", "Atlas"], ["bridges", "Bridges"], ["gaps", "Gaps"], ["patterns", "Patterns"]] as const) {
			const button = modes.createEl("button", { cls: `elf-atlas-mode-button${value === this.mode ? " is-active" : ""}`, text: label });
			button.dataset.mode = value;
			button.addEventListener("click", () => this.setMode(value, modes));
		}

		const reset = controls.createEl("button", { cls: "elf-atlas-icon-button", attr: { "aria-label": "Frame the full atlas", "data-tooltip-position": "bottom" } });
		setIcon(reset, "scan");
		reset.addEventListener("click", () => {
			this.resetInsightState();
			this.selectNode(null);
			this.renderer?.setPath(null);
			this.renderer?.frameAll();
		});

		this.legendEl = this.rootEl.createDiv({ cls: "elf-atlas-legend" });
		this.cardEl = this.rootEl.createEl("aside", { cls: "elf-atlas-card", attr: { "aria-live": "polite" } });
		this.tooltipEl = this.rootEl.createDiv({ cls: "elf-atlas-tooltip" });
		this.railEl = this.rootEl.createDiv({ cls: "elf-atlas-lens-rail" });

		const footer = this.rootEl.createDiv({ cls: "elf-atlas-footer" });
		footer.createSpan({ cls: "elf-atlas-encoding", text: "Height = conceptual distance · color = topic · bright lines = the structure in focus" });
		footer.createSpan({ cls: "elf-atlas-help", text: "Drag to orbit · right-drag to pan · scroll to zoom · double-click to open" });

		this.emptyEl = this.rootEl.createDiv({ cls: "elf-atlas-empty" });
		this.emptyEl.createEl("h3", { text: "No Concept Graph notes yet" });
		this.emptyEl.createEl("p", { text: "The atlas appears when notes live inside a Concept Graph folder." });

		const modeNote = this.rootEl.createDiv({ cls: "elf-atlas-mode-note" });
		modeNote.dataset.role = "mode-note";
		this.updateModeNote();
	}

	private setMode(mode: AtlasMode, controls?: HTMLElement): void {
		this.mode = mode;
		this.resetInsightState();
		this.renderer?.setPath(null);
		this.renderer?.setMode(mode);
		controls?.querySelectorAll("button").forEach((item) => item.toggleClass("is-active", (item as HTMLElement).dataset.mode === mode));
		this.updateModeNote();
		this.renderLensRail();
		if (mode === "patterns" && this.model?.patterns.length) this.selectPattern(this.model.patterns[0].id);
		else this.selectNode(null);
	}

	private updateModeNote(): void {
		const note = this.rootEl?.querySelector<HTMLElement>("[data-role='mode-note']");
		if (!note) return;
		const text: Record<AtlasMode, string> = {
			atlas: "Your declared structure. Select an idea to trace what it builds on and what it opens next.",
			bridges: "Possible links between distant clusters · select a violet arc or an idea.",
			gaps: "Linked ideas whose transition is not yet clear · select an amber line.",
			patterns: "Shapes that recur across different clusters · choose one below.",
		};
		note.setText(text[this.mode]);
		note.toggleClass("is-visible", this.mode !== "atlas");
	}

	private renderLensRail(): void {
		if (!this.railEl || !this.model) return;
		this.railEl.empty();
		this.railEl.toggleClass("is-visible", this.mode === "patterns" && this.model.patterns.length > 0);
		if (this.mode !== "patterns") return;
		this.railEl.createSpan({ cls: "elf-atlas-rail-label", text: "RECURRING SHAPES" });
		for (const pattern of this.model.patterns.slice(0, 8)) {
			const button = this.railEl.createEl("button", { cls: pattern.id === this.selectedPatternId ? "is-active" : "", text: pattern.label });
			button.dataset.patternId = pattern.id;
			button.addEventListener("click", () => this.selectPattern(pattern.id));
		}
	}

	private renderLegend(): void {
		if (!this.legendEl || !this.model) return;
		this.legendEl.empty();
		this.legendEl.createDiv({ cls: "elf-atlas-panel-label", text: "TOPICS · CLICK TO FOCUS" });
		const list = this.legendEl.createDiv({ cls: "elf-atlas-topic-list" });
		for (const topic of this.model.topics) {
			const button = list.createEl("button", { cls: "elf-atlas-topic is-active", attr: { "aria-pressed": "true" } });
			const dot = button.createSpan({ cls: "elf-atlas-topic-dot" });
			dot.style.backgroundColor = topic.color;
			button.createSpan({ cls: "elf-atlas-topic-name", text: topic.label });
			button.createSpan({ cls: "elf-atlas-topic-count", text: String(topic.count) });
			button.dataset.topic = topic.id;
			button.addEventListener("click", (event) => {
				if (event.altKey || event.metaKey) this.activeTopics = new Set([topic.id]);
				else if (this.activeTopics.has(topic.id) && this.activeTopics.size > 1) this.activeTopics.delete(topic.id);
				else this.activeTopics.add(topic.id);
				for (const item of list.querySelectorAll<HTMLElement>(".elf-atlas-topic")) {
					const active = this.activeTopics.has(item.dataset.topic!);
					item.toggleClass("is-active", active);
					item.setAttribute("aria-pressed", String(active));
				}
				this.renderer?.setActiveTopics(this.activeTopics);
			});
		}
		const summary = this.legendEl.createDiv({ cls: "elf-atlas-legend-summary" });
		summary.createSpan({ text: `${this.model.nodes.length} ideas` });
		summary.createSpan({ text: `${this.model.edges.length} connections` });
	}

	private resetInsightState(): void {
		this.selectedProposalId = null;
		this.selectedGapId = null;
		this.selectedPatternId = null;
		this.selectedPathId = null;
		this.patternInstance = 0;
		this.renderer?.setFocusedProposal(null);
		this.renderer?.setFocusedGap(null);
		this.renderer?.setPattern(null);
	}

	private selectNode(nodeId: string | null): void {
		this.selectedProposalId = null;
		this.selectedGapId = null;
		this.renderer?.setFocusedProposal(null);
		this.renderer?.setFocusedGap(null);
		this.selectedPathId = null;
		this.renderer?.setPath(null);
		if (!nodeId || !this.model) {
			this.selection = null;
			this.renderer?.setSelection(null);
			if (this.mode !== "patterns") this.cardEl?.removeClass("is-visible");
			this.searchResultsEl?.removeClass("is-visible");
			return;
		}
		this.selection = selectionFor(this.model, nodeId);
		this.renderer?.setSelection(this.selection);
		this.renderCard();
	}

	private selectInsight(kind: "bridge" | "gap", id: string): void {
		this.selection = null;
		this.renderer?.setSelection(null);
		this.selectedPathId = null;
		this.renderer?.setPath(null);
		if (kind === "bridge") {
			this.selectedProposalId = id;
			this.selectedGapId = null;
			this.renderer?.setFocusedProposal(id);
		} else {
			this.selectedGapId = id;
			this.selectedProposalId = null;
			this.renderer?.setFocusedGap(id);
		}
		this.renderCard();
	}

	private selectPattern(patternId: string): void {
		this.selectedPatternId = patternId;
		this.selection = null;
		this.patternInstance = 0;
		this.renderer?.setSelection(null);
		this.renderer?.setPattern(patternId);
		this.renderLensRail();
		this.renderCard();
	}

	private renderCard(): void {
		if (!this.cardEl || !this.model) return;
		this.cardEl.empty();
		if (this.selectedProposalId) {
			const proposal = this.model.proposals.find((candidate) => candidate.id === this.selectedProposalId);
			if (proposal) this.renderBridgeCard(proposal);
			return;
		}
		if (this.selectedGapId) {
			const gap = this.model.weakTransitions.find((candidate) => candidate.edgeId === this.selectedGapId);
			if (gap) this.renderGapCard(gap);
			return;
		}
		if (this.mode === "patterns" && this.selectedPatternId) {
			const pattern = this.model.patterns.find((candidate) => candidate.id === this.selectedPatternId);
			if (pattern) this.renderPatternCard(pattern);
			return;
		}
		if (!this.selection) {
			this.cardEl.removeClass("is-visible");
			return;
		}
		const node = this.model.nodes.find((candidate) => candidate.id === this.selection!.selectedId);
		if (node) this.renderNodeCard(node);
	}

	private cardHeader(metaText: string, color: string): void {
		if (!this.cardEl) return;
		this.cardEl.addClass("is-visible");
		const top = this.cardEl.createDiv({ cls: "elf-atlas-card-top" });
		const meta = top.createDiv({ cls: "elf-atlas-card-meta" });
		const dot = meta.createSpan({ cls: "elf-atlas-card-dot" });
		dot.style.backgroundColor = color;
		meta.createSpan({ text: metaText });
		const close = top.createEl("button", { cls: "elf-atlas-card-close", attr: { "aria-label": "Close card" } });
		setIcon(close, "x");
		close.addEventListener("click", () => {
			if (this.mode === "patterns") this.setMode("atlas", this.rootEl?.querySelector(".elf-atlas-mode") ?? undefined);
			else this.selectNode(null);
		});
	}

	private renderNodeCard(node: AtlasNode): void {
		if (!this.cardEl || !this.model || !this.selection) return;
		const color = this.model.topics.find((topic) => topic.id === node.topic)?.color ?? "#9fb4cc";
		this.cardHeader(`${node.topic} · ${node.category} · layer ${node.depth}`, color);
		this.cardEl.createEl("h2", { text: node.title });
		this.cardEl.createEl("p", { cls: "elf-atlas-excerpt", text: node.excerpt });

		const metric = this.cardEl.createDiv({ cls: "elf-atlas-metric" });
		metric.createSpan({ cls: "elf-atlas-metric-number", text: String(this.selection.ancestorIds.size) });
		const metricCopy = metric.createDiv();
		metricCopy.createEl("strong", { text: "foundations traced" });
		metricCopy.createSpan({ text: "Connections followed back toward this cluster’s organizing idea." });

		this.renderRelationList("BUILDS DIRECTLY ON", this.selection.directFoundationIds);
		this.renderRelationList("OPENS NEXT", this.selection.directNextIds);
		if (this.mode === "bridges") this.renderBridgeRows(node);
		else if (this.mode === "gaps") this.renderGapRows(node);
		else this.renderPaths(node);

		const actions = this.cardEl.createDiv({ cls: "elf-atlas-card-actions" });
		const open = actions.createEl("button", { cls: "mod-cta", text: "Open note" });
		const icon = open.createSpan({ cls: "elf-atlas-action-icon" });
		setIcon(icon, "arrow-up-right");
		open.prepend(icon);
		open.addEventListener("click", () => void this.openNode(node.id));
	}

	private renderBridgeCard(proposal: RelationProposal): void {
		if (!this.cardEl || !this.model) return;
		const source = this.model.nodes.find((node) => node.id === proposal.source);
		const target = this.model.nodes.find((node) => node.id === proposal.target);
		if (!source || !target) return;
		this.cardHeader(`POSSIBLE BRIDGE · ${source.topic} ↔ ${target.topic}`, "#c5a5ff");
		const title = this.cardEl.createDiv({ cls: "elf-atlas-insight-title" });
		const sourceButton = title.createEl("button", { text: source.title });
		sourceButton.addEventListener("click", () => this.selectNode(source.id));
		title.createSpan({ text: proposal.workingPredicate ?? proposal.surfacePredicates[0] ?? "may connect to" });
		const targetButton = title.createEl("button", { text: target.title });
		targetButton.addEventListener("click", () => this.selectNode(target.id));
		this.cardEl.createEl("p", { cls: "elf-atlas-insight-question", text: proposal.question });

		const why = this.cardEl.createDiv({ cls: "elf-atlas-card-section elf-atlas-why" });
		why.createDiv({ cls: "elf-atlas-section-label", text: "WHY THIS APPEARED" });
		for (const signal of proposal.signals.filter((item) => item.kind !== "distant-clusters").slice(0, 3)) {
			const row = why.createDiv();
			row.createEl("strong", { text: signal.explanation });
			if (signal.details.length) row.createSpan({ text: signal.details.slice(0, 4).join(" · ") });
		}

		const change = this.cardEl.createDiv({ cls: "elf-atlas-change" });
		change.createEl("strong", { text: "What it changes" });
		change.createSpan({ text: `This would create a direct route between ${source.topic} and ${target.topic}.` });

		const actions = this.cardEl.createDiv({ cls: "elf-atlas-card-actions" });
		const keep = actions.createEl("button", { text: proposal.reviewStatus === "kept" ? "Kept" : "Keep connection" });
		keep.disabled = proposal.reviewStatus === "kept";
		keep.addEventListener("click", () => void this.plugin.reviewProposal(proposal.id, "keep"));
		const name = actions.createEl("button", { cls: "mod-cta", text: proposal.reviewStatus === "named" ? "Revise name…" : "Name connection…" });
		name.addEventListener("click", () => new NameConnectionModal(this.plugin, proposal).open());
		const dismiss = actions.createEl("button", { text: "Not useful" });
		dismiss.addEventListener("click", () => void this.plugin.reviewProposal(proposal.id, "dismiss"));
	}

	private renderGapCard(gap: WeakTransition): void {
		if (!this.cardEl || !this.model) return;
		const source = this.model.nodes.find((node) => node.id === gap.source);
		const target = this.model.nodes.find((node) => node.id === gap.target);
		if (!source || !target) return;
		this.cardHeader(`UNEXPLAINED TRANSITION · ${source.topic}`, "#e0ad76");
		this.cardEl.createEl("h2", { text: `${source.title} → ${target.title}` });
		this.cardEl.createEl("p", { cls: "elf-atlas-insight-question", text: "What idea makes this jump intelligible?" });
		const why = this.cardEl.createDiv({ cls: "elf-atlas-card-section elf-atlas-why" });
		why.createDiv({ cls: "elf-atlas-section-label", text: "WHAT THE CURRENT STRUCTURE LEAVES OPEN" });
		for (const reason of gap.reasons) {
			const row = why.createDiv();
			row.createEl("strong", { text: reason.explanation });
		}
		const actions = this.cardEl.createDiv({ cls: "elf-atlas-card-actions" });
		const first = actions.createEl("button", { text: `Open ${source.title}` });
		first.addEventListener("click", () => void this.openNode(source.id));
		const second = actions.createEl("button", { text: `Open ${target.title}` });
		second.addEventListener("click", () => void this.openNode(target.id));
	}

	private renderPatternCard(pattern: AtlasPattern): void {
		if (!this.cardEl || !this.model) return;
		this.cardHeader(`RECURRING SHAPE · ${pattern.topics.length} CLUSTERS`, "#79ccb2");
		this.cardEl.createEl("h2", { text: pattern.label });
		this.cardEl.createEl("p", { cls: "elf-atlas-insight-question", text: "The same structural sequence appears in different parts of your atlas. The highlighted paths show each occurrence." });
		const topicLine = this.cardEl.createDiv({ cls: "elf-atlas-pattern-topics" });
		for (const topic of pattern.topics) topicLine.createSpan({ text: topic });

		const instance = pattern.instances[this.patternInstance % pattern.instances.length] ?? [];
		const section = this.cardEl.createDiv({ cls: "elf-atlas-card-section" });
		section.createDiv({ cls: "elf-atlas-section-label", text: `ONE INSTANCE · ${this.patternInstance + 1} OF ${pattern.instances.length}` });
		const chain = section.createDiv({ cls: "elf-atlas-path-chain" });
		instance.forEach((id, index) => {
			if (index) chain.createSpan({ text: "→" });
			const node = this.model!.nodes.find((candidate) => candidate.id === id);
			const button = chain.createEl("button", { text: node?.title ?? id });
			button.addEventListener("click", () => this.selectNode(id));
		});

		if (pattern.instances.length > 1) {
			const actions = this.cardEl.createDiv({ cls: "elf-atlas-card-actions" });
			const previous = actions.createEl("button", { text: "Previous instance" });
			previous.addEventListener("click", () => {
				this.patternInstance = (this.patternInstance - 1 + pattern.instances.length) % pattern.instances.length;
				this.renderer?.focusNodes(pattern.instances[this.patternInstance] ?? []);
				this.renderCard();
			});
			const next = actions.createEl("button", { cls: "mod-cta", text: "Next instance" });
			next.addEventListener("click", () => {
				this.patternInstance = (this.patternInstance + 1) % pattern.instances.length;
				this.renderer?.focusNodes(pattern.instances[this.patternInstance] ?? []);
				this.renderCard();
			});
		}
	}

	private renderRelationList(label: string, ids: Set<string>): void {
		if (!this.cardEl || !this.model || ids.size === 0) return;
		const section = this.cardEl.createDiv({ cls: "elf-atlas-card-section" });
		section.createDiv({ cls: "elf-atlas-section-label", text: `${label}  ${ids.size}` });
		for (const id of [...ids].slice(0, 6)) {
			const node = this.model.nodes.find((candidate) => candidate.id === id);
			if (!node) continue;
			const button = section.createEl("button", { cls: "elf-atlas-related" });
			button.createSpan({ cls: "elf-atlas-related-dot" });
			button.createSpan({ cls: "elf-atlas-related-name", text: node.title });
			button.createSpan({ cls: "elf-atlas-related-layer", text: `L${node.depth}` });
			button.addEventListener("click", () => this.selectNode(node.id));
		}
	}

	private renderBridgeRows(node: AtlasNode): void {
		if (!this.cardEl || !this.model) return;
		const proposals = this.model.proposals
			.filter((proposal) => proposal.reviewStatus !== "dismissed" && (proposal.family === "cross-topic-bridge" || proposal.family === "analogy") && (proposal.source === node.id || proposal.target === node.id))
			.slice(0, 5);
		if (!proposals.length) return;
		const section = this.cardEl.createDiv({ cls: "elf-atlas-card-section" });
		section.createDiv({ cls: "elf-atlas-section-label", text: `POSSIBLE BRIDGES  ${proposals.length}` });
		for (const proposal of proposals) {
			const otherId = proposal.source === node.id ? proposal.target : proposal.source;
			const other = this.model.nodes.find((candidate) => candidate.id === otherId);
			if (!other) continue;
			const button = section.createEl("button", { cls: "elf-atlas-related elf-atlas-related-insight" });
			button.createSpan({ cls: "elf-atlas-related-dot is-bridge" });
			button.createSpan({ cls: "elf-atlas-related-name", text: other.title });
			button.createSpan({ cls: "elf-atlas-related-layer", text: other.topic });
			button.addEventListener("click", () => this.selectInsight("bridge", proposal.id));
		}
	}

	private renderGapRows(node: AtlasNode): void {
		if (!this.cardEl || !this.model) return;
		const gaps = this.model.weakTransitions.filter((gap) => gap.source === node.id || gap.target === node.id).slice(0, 5);
		if (!gaps.length) return;
		const section = this.cardEl.createDiv({ cls: "elf-atlas-card-section" });
		section.createDiv({ cls: "elf-atlas-section-label", text: `UNCLEAR TRANSITIONS  ${gaps.length}` });
		for (const gap of gaps) {
			const otherId = gap.source === node.id ? gap.target : gap.source;
			const other = this.model.nodes.find((candidate) => candidate.id === otherId);
			if (!other) continue;
			const button = section.createEl("button", { cls: "elf-atlas-related elf-atlas-related-insight" });
			button.createSpan({ cls: "elf-atlas-related-dot is-gap" });
			button.createSpan({ cls: "elf-atlas-related-name", text: other.title });
			button.createSpan({ cls: "elf-atlas-related-layer", text: gap.reasons[0]?.kind.replace(/-/g, " ") ?? "unclear" });
			button.addEventListener("click", () => this.selectInsight("gap", gap.edgeId));
		}
	}

	private renderPaths(node: AtlasNode): void {
		if (!this.cardEl || !this.model) return;
		const paths = intelligibilityPaths(this.model, node.id).slice(0, 3);
		if (!paths.length) return;
		const section = this.cardEl.createDiv({ cls: "elf-atlas-card-section elf-atlas-paths" });
		section.createDiv({ cls: "elf-atlas-section-label", text: "WAYS THROUGH THIS IDEA" });
		for (const path of paths) {
			const button = section.createEl("button", { cls: `elf-atlas-path${path.id === this.selectedPathId ? " is-active" : ""}` });
			button.createEl("strong", { text: path.label });
			button.createSpan({ text: this.pathSummary(path) });
			if (path.bottleneckReasons.length) button.createEl("small", { text: "contains an unexplained transition" });
			button.addEventListener("click", () => {
				this.selectedPathId = this.selectedPathId === path.id ? null : path.id;
				this.renderer?.setPath(this.selectedPathId ? path.nodeIds : null);
				this.renderCard();
			});
		}
	}

	private pathSummary(path: IntelligibilityPath): string {
		if (!this.model) return "";
		return path.nodeIds.map((id) => this.model!.nodes.find((node) => node.id === id)?.title ?? id).join(" → ");
	}

	private searchMatches(): AtlasNode[] {
		if (!this.model || !this.searchEl) return [];
		const query = this.searchEl.value.trim().toLowerCase();
		if (!query) return [];
		return this.model.nodes
			.filter((node) => `${node.title} ${node.topic} ${node.category}`.toLowerCase().includes(query))
			.sort((a, b) => (a.title.toLowerCase().startsWith(query) ? -1 : 0) - (b.title.toLowerCase().startsWith(query) ? -1 : 0) || a.title.localeCompare(b.title))
			.slice(0, 8);
	}

	private renderSearchResults(): void {
		if (!this.searchResultsEl) return;
		this.searchResultsEl.empty();
		const matches = this.searchMatches();
		this.searchResultsEl.toggleClass("is-visible", matches.length > 0);
		for (const node of matches) {
			const button = this.searchResultsEl.createEl("button", { attr: { role: "option" } });
			button.createEl("strong", { text: node.title });
			button.createSpan({ text: node.topic });
			button.addEventListener("click", () => this.chooseSearchResult(node.id));
		}
	}

	private chooseSearchResult(nodeId: string): void {
		const node = this.model?.nodes.find((candidate) => candidate.id === nodeId);
		if (!node) return;
		if (this.mode !== "atlas") this.setMode("atlas", this.rootEl?.querySelector(".elf-atlas-mode") ?? undefined);
		this.activeTopics.add(node.topic);
		this.renderer?.setActiveTopics(this.activeTopics);
		this.selectNode(nodeId);
		if (this.searchEl) this.searchEl.value = node.title;
		this.searchResultsEl?.removeClass("is-visible");
	}

	private showTooltip(nodeId: string | null, point: { x: number; y: number } | null): void {
		if (!this.tooltipEl || !this.model || !nodeId || !point) {
			this.tooltipEl?.removeClass("is-visible");
			return;
		}
		const node = this.model.nodes.find((candidate) => candidate.id === nodeId);
		if (!node) return;
		this.tooltipEl.empty();
		this.tooltipEl.createEl("strong", { text: node.title });
		this.tooltipEl.createSpan({ text: `${node.topic} · layer ${node.depth}` });
		const rootRect = this.rootEl?.getBoundingClientRect();
		if (!rootRect) return;
		this.tooltipEl.style.left = `${Math.min(rootRect.width - 220, Math.max(12, point.x - rootRect.left + 14))}px`;
		this.tooltipEl.style.top = `${Math.min(rootRect.height - 80, Math.max(72, point.y - rootRect.top + 14))}px`;
		this.tooltipEl.addClass("is-visible");
	}

	private async openNode(nodeId: string): Promise<void> {
		const file = this.app.vault.getAbstractFileByPath(nodeId);
		if (file instanceof TFile) await this.app.workspace.getLeaf(false).openFile(file);
	}

	private setLoading(loading: boolean): void {
		this.rootEl?.toggleClass("is-loading", loading);
	}
}
