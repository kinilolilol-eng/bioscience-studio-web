import { Notice, Plugin, WorkspaceLeaf } from "obsidian";
import { AtlasReviewLedger } from "./atlas/ledger";
import { buildAtlasModel } from "./atlas/model";
import { applyProposalReviews } from "./atlas/review";
import { AtlasLedgerEvent, AtlasModel, ReviewAction } from "./atlas/types";
import { PersonalAtlasView, VIEW_TYPE_ATLAS } from "./atlas/view";

export default class PersonalAtlasPlugin extends Plugin {
	private modelPromise: Promise<AtlasModel> | null = null;
	private refreshTimer: number | null = null;
	private ledger!: AtlasReviewLedger;

	async onload(): Promise<void> {
		this.ledger = new AtlasReviewLedger(this.app, this.manifest.id);
		await this.ledger.load();
		if (this.ledger.invalidLineNumbers().length) {
			new Notice(`Personal Knowledge Atlas ignored ${this.ledger.invalidLineNumbers().length} malformed review-ledger line(s). The valid history is still active.`);
		}
		this.removeRejectedViews();
		this.app.workspace.onLayoutReady(() => this.removeRejectedViews());
		this.registerView(VIEW_TYPE_ATLAS, (leaf) => new PersonalAtlasView(leaf, this));
		this.addRibbonIcon("orbit", "Open Personal Knowledge Atlas", () => void this.activate());
		this.addCommand({ id: "open-atlas", name: "Open Personal Knowledge Atlas", callback: () => void this.activate() });
		this.addCommand({ id: "open-graph", name: "Open Personal Knowledge Atlas", callback: () => void this.activate() });
		this.addCommand({
			id: "open-active-concept",
			name: "Show active Concept Graph note in Atlas",
			checkCallback: (checking) => {
				const file = this.app.workspace.getActiveFile();
				const available = Boolean(file?.path.includes("/Concept Graph/"));
				if (!checking && file && available) void this.activate(file.path);
				return available;
			},
		});
		this.addCommand({ id: "rebuild-atlas", name: "Rebuild Personal Knowledge Atlas", callback: () => void this.rebuildOpenViews() });

		const schedule = (path: string) => {
			if (!path.includes("/Concept Graph/")) return;
			if (this.refreshTimer !== null) window.clearTimeout(this.refreshTimer);
			this.refreshTimer = window.setTimeout(() => void this.rebuildOpenViews(), 650);
		};
		this.registerEvent(this.app.vault.on("create", (file) => schedule(file.path)));
		this.registerEvent(this.app.vault.on("modify", (file) => schedule(file.path)));
		this.registerEvent(this.app.vault.on("delete", (file) => schedule(file.path)));
		this.registerEvent(this.app.vault.on("rename", (file, oldPath) => { schedule(file.path); schedule(oldPath); }));
	}

	onunload(): void {
		if (this.refreshTimer !== null) window.clearTimeout(this.refreshTimer);
		this.app.workspace.detachLeavesOfType(VIEW_TYPE_ATLAS);
	}

	async getModel(force = false): Promise<AtlasModel> {
		if (force || !this.modelPromise) this.modelPromise = buildAtlasModel(this.app);
		const model = await this.modelPromise;
		const proposals = applyProposalReviews(model.proposals, [...this.ledger.allEvents()]);
		const dismissed = new Set(proposals.filter((proposal) => proposal.reviewStatus === "dismissed").map((proposal) => proposal.id));
		return {
			...model,
			proposals,
			bridges: model.bridges.filter((bridge) => !dismissed.has(bridge.id)),
			voids: model.voids.filter((candidate) => !dismissed.has(candidate.id)),
		};
	}

	async activate(nodeId?: string): Promise<void> {
		const existing = this.app.workspace.getLeavesOfType(VIEW_TYPE_ATLAS);
		let leaf = existing.find((candidate) => candidate.view instanceof PersonalAtlasView);
		for (const stale of existing.filter((candidate) => !(candidate.view instanceof PersonalAtlasView))) stale.detach();
		if (!leaf) {
			leaf = this.app.workspace.getLeaf(true);
			await leaf.setViewState({ type: VIEW_TYPE_ATLAS, active: true });
		}
		await this.app.workspace.revealLeaf(leaf);
		if (nodeId && leaf.view instanceof PersonalAtlasView) leaf.view.focusConcept(nodeId);
	}

	async reviewProposal(proposalId: string, action: ReviewAction, payload: Record<string, unknown> = {}): Promise<void> {
		await this.ledger.reviewProposal(proposalId, action, payload);
		await this.refreshOpenViews(false);
		const label = action === "restore" ? "restored" : action === "keep" ? "kept" : action === "name" ? "named" : action === "revise" ? "revised" : "dismissed";
		new Notice(`Possible connection ${label}. Your notes were not changed.`);
	}

	ledgerEvents(): readonly AtlasLedgerEvent[] {
		return this.ledger.allEvents();
	}

	private async rebuildOpenViews(): Promise<void> {
		this.modelPromise = null;
		await this.getModel(false);
		await this.refreshOpenViews(false);
	}

	private async refreshOpenViews(force: boolean): Promise<void> {
		const atlasLeaves = this.app.workspace.getLeavesOfType(VIEW_TYPE_ATLAS);
		await Promise.all(atlasLeaves.map((leaf: WorkspaceLeaf) => leaf.view instanceof PersonalAtlasView ? leaf.view.reload(force) : Promise.resolve()));
	}

	private removeRejectedViews(): void {
		this.app.workspace.detachLeavesOfType("elf-relation-studio");
	}
}
