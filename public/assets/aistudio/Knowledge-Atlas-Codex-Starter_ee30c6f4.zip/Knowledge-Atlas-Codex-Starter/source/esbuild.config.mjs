import esbuild from "esbuild";
import process from "node:process";
import path from "node:path";
import builtins from "builtin-modules";

const prod = process.argv[2] === "production";

/**
 * Resolves `import workerSource from "virtual:worker:src/foo/worker.ts"` by
 * bundling the referenced entry point as a standalone IIFE and exporting its
 * source text. The runtime turns that text into a Blob URL and spawns a real
 * Web Worker from it — the only way to ship workers inside Obsidian's
 * single-file `main.js` constraint.
 */
const inlineWorkerPlugin = {
	name: "inline-worker",
	setup(build) {
		build.onResolve({ filter: /^virtual:worker:/ }, (args) => ({
			path: args.path.slice("virtual:worker:".length),
			namespace: "inline-worker",
		}));
		build.onLoad({ filter: /.*/, namespace: "inline-worker" }, async (args) => {
			const entry = path.resolve(process.cwd(), args.path);
			const result = await esbuild.build({
				entryPoints: [entry],
				bundle: true,
				write: false,
				format: "iife",
				platform: "browser",
				target: "es2022",
				minify: prod,
				logLevel: "silent",
			});
			return {
				contents: `export default ${JSON.stringify(result.outputFiles[0].text)};`,
				loader: "js",
				resolveDir: path.dirname(entry),
				watchFiles: [entry],
			};
		});
	},
};

const ctx = await esbuild.context({
	entryPoints: ["src/atlas-main.ts"],
	bundle: true,
	external: [
		"obsidian",
		"electron",
		"@codemirror/*",
		"@lezer/*",
		...builtins,
	],
	format: "cjs",
	target: "es2022",
	logLevel: "info",
	sourcemap: prod ? false : "inline",
	treeShaking: true,
	outfile: "main.js",
	plugins: [inlineWorkerPlugin],
});

if (prod) {
	await ctx.rebuild();
	process.exit(0);
} else {
	await ctx.watch();
}
