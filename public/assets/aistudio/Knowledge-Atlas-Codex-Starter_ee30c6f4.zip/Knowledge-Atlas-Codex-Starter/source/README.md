# Personal Knowledge Atlas source

This is the editable production source for the data-free starter.

```sh
npm install
npm run check
npm test
npm run build
```

The production build writes `main.js` in this directory. A manual Obsidian installation consists of:

```text
main.js
manifest.json
styles.css
versions.json
```

The vault-facing adapter is `src/atlas/model.ts`. The remaining Atlas implementation is intentionally preserved from the production build.

