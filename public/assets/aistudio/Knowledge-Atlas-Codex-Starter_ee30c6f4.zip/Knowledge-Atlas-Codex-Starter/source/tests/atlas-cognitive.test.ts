import assert from "node:assert/strict";
import { discoverCognitiveLayer, intelligibilityPaths } from "../src/atlas/discovery";
import { applyProposalReviews, replayProposalReviews } from "../src/atlas/review";
import { AtlasEdge, AtlasLedgerEvent, AtlasModel, AtlasNode, AtlasTopic, RelationProposal, ReviewAction } from "../src/atlas/types";

function node(id: string, topic: string, overrides: Partial<AtlasNode> = {}): AtlasNode {
	return {
		id,
		path: id,
		title: id,
		topic,
		category: "Core",
		meaningRef: null,
		meaningPath: `${topic}.md`,
		meaningHeading: id,
		excerpt: "",
		analysisText: "",
		depth: 0,
		degree: 0,
		centrality: 0,
		position: { x: 0, y: 0, z: 0 },
		...overrides,
	};
}

function edge(a: AtlasNode, b: AtlasNode, declaredBy: string[] = [a.id, b.id]): AtlasEdge {
	const [source, target] = [a.id, b.id].sort();
	return { id: `${source}::${target}`, source, target, topic: a.topic, type: "declared", declaredBy };
}

const production = node("Interpretive Frame", "Understanding", {
	analysisText: "Interpretive Frame depends on Prior Assumption when a conclusion is read within a particular context.",
});
const gradient = node("Prior Assumption", "Understanding", { depth: 1 });
const worded = discoverCognitiveLayer([production, gradient], [edge(production, gradient, [production.id])]);
const dependency = worded.proposals.find((proposal) => proposal.family === "dependency" && proposal.source === production.id && proposal.target === gradient.id);
assert(dependency, "explicit wording becomes a possible dependency");
assert.equal(dependency.basis, "explicit-wording");
assert.deepEqual(dependency.surfacePredicates, ["depends on"], "the user's wording is retained instead of silently canonicalized");
assert.equal(dependency.direction, "forward");
assert.equal(dependency.contexts[0].matchKind, "both-named");
assert(!("reviewPriority" in dependency), "a possible connection has no scalar leaderboard score");
assert(worded.weakTransitions[0].reasons.some((reason) => reason.kind === "one-way-link"), "one-way authorship stays visible");

const context = node("Adjacent View", "Understanding", {
	analysisText: "An Adjacent View can change how Prior Assumption is interpreted when the surrounding frame shifts.",
});
const contextual = discoverCognitiveLayer([context, gradient], []).proposals.find((proposal) => proposal.source === context.id && proposal.target === gradient.id);
assert.equal(contextual?.basis, "shared-context", "nearby mention remains a tentative connection, not an asserted relation");

const distantA = node("Learning Loop", "Learning", {
	category: "Models",
	meaningPath: "learning-note.md",
	analysisText: "A reversible constraint changes which options become available across nested contexts and shifting priorities.",
});
const distantB = node("Design Loop", "Design", {
	category: "Models",
	meaningPath: "design-note.md",
	analysisText: "A reversible constraint changes which options become available across nested contexts and shifting priorities.",
});
const bridgeRunA = discoverCognitiveLayer([distantA, distantB], []);
const bridgeRunB = discoverCognitiveLayer([distantA, distantB], []);
const bridge = bridgeRunA.proposals.find((proposal) => proposal.family === "analogy" || proposal.family === "cross-topic-bridge");
assert(bridge, "a distinctive repeated formulation across distant clusters becomes a possible bridge");
assert.equal(bridge.basis, "shared-meaning");
assert(bridge.signals.some((signal) => signal.kind === "distant-clusters"));
assert(bridge.signals.some((signal) => signal.kind === "independent-notes"));
assert.deepEqual(bridgeRunA.proposals.map((proposal) => proposal.id), bridgeRunB.proposals.map((proposal) => proposal.id), "connection identity is deterministic");

const genericA = node("Generic Alpha", "Alpha", { analysisText: "This concept uses a model and system with several effects in the same phase." });
const genericB = node("Generic Beta", "Beta", { analysisText: "This concept uses a model and system with several effects in the same phase." });
assert.equal(discoverCognitiveLayer([genericA, genericB], []).proposals.length, 0, "generic overlap does not manufacture a bridge");

const left = node("Left", "Topology");
const right = node("Right", "Topology");
const middleA = node("Middle A", "Topology", { depth: 1 });
const middleB = node("Middle B", "Topology", { depth: 1 });
const gapLayer = discoverCognitiveLayer([left, right, middleA, middleB], [edge(left, middleA), edge(right, middleA), edge(left, middleB), edge(right, middleB)]);
assert(gapLayer.proposals.some((proposal) => proposal.family === "structural-gap" && [proposal.source, proposal.target].includes(left.id) && [proposal.source, proposal.target].includes(right.id)), "a missing connection with shared neighbors becomes a visual question");

const patternNodes: AtlasNode[] = [];
const patternEdges: AtlasEdge[] = [];
for (const topic of ["One", "Two", "Three"]) {
	const root = node(`${topic} Root`, topic, { category: "Core", depth: 0 });
	const model = node(`${topic} Model`, topic, { category: "Models", depth: 1 });
	const use = node(`${topic} Use`, topic, { category: "Use and Audit", depth: 2 });
	patternNodes.push(root, model, use);
	patternEdges.push(edge(root, model), edge(model, use));
}
const patterned = discoverCognitiveLayer(patternNodes, patternEdges);
assert(patterned.patterns.some((pattern) => pattern.label === "Core → Models" && pattern.topics.length === 3), "a repeated shape across clusters is surfaced as a visual pattern");

const [root, model, use] = patternNodes.slice(0, 3);
const selectedModel: AtlasModel = {
	nodes: [root, model, use],
	edges: [edge(root, model), edge(model, use, [model.id])],
	bridges: [],
	voids: [],
	proposals: [],
	weakTransitions: [{
		edgeId: edge(model, use).id,
		source: model.id,
		target: use.id,
		reasons: [{ kind: "missing-explanation", explanation: "The transition is not explicit." }],
		contexts: [],
	}],
	patterns: [],
	topics: [{ id: "One", label: "One", color: "#fff", count: 3, rootIds: [root.id] } satisfies AtlasTopic],
	builtAt: 1,
};
const paths = intelligibilityPaths(selectedModel, use.id);
const foundationPath = paths.find((path) => path.objective === "foundations");
assert.deepEqual(foundationPath?.nodeIds, [root.id, model.id, use.id], "an understanding path makes the route through the atlas explicit");
assert.equal(foundationPath?.bottleneckEdgeId, edge(model, use).id, "the unclear transition remains visible in the path");

const reviewedProposal = dependency as RelationProposal;
function event(sequence: number, action: ReviewAction, payload: Record<string, unknown> = {}): AtlasLedgerEvent {
	return {
		schemaVersion: 1,
		eventId: `event-${sequence}`,
		timestamp: `2026-07-12T12:00:0${sequence}.000Z`,
		actor: "user",
		entity: "proposal",
		entityId: reviewedProposal.id,
		action,
		payload,
	};
}
const reviewEvents = [
	event(1, "keep"),
	event(2, "name", { predicate: "is bounded by", note: "Useful when distinguishing direct and indirect dependence" }),
	event(3, "dismiss"),
	event(4, "restore"),
];
const reviewState = replayProposalReviews(reviewEvents).get(reviewedProposal.id);
assert.equal(reviewState?.status, "named", "restore recovers the last non-dismissed personal judgment");
assert.equal(reviewState?.workingPredicate, "is bounded by");
assert.equal(reviewState?.note, "Useful when distinguishing direct and indirect dependence");
const applied = applyProposalReviews([reviewedProposal], reviewEvents)[0];
assert.equal(applied.reviewStatus, "named");
assert.equal(applied.workingPredicate, "is bounded by");

console.log("atlas cognitive-layer tests passed");
