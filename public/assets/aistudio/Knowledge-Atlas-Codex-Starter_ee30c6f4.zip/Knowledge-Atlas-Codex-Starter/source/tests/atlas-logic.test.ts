import assert from "node:assert/strict";
import { assignDepths, chooseRoots, discoverBridges, discoverVoids, selectionFor } from "../src/atlas/logic";
import { layOutAtlas } from "../src/atlas/layout";
import { AtlasEdge, AtlasNode } from "../src/atlas/types";

const node = (id: string, topic: string, category = "Core", excerpt = ""): AtlasNode => ({
	id,
	path: id,
	title: id,
	topic,
	category,
	meaningRef: null,
	meaningPath: null,
	meaningHeading: null,
	excerpt,
	analysisText: excerpt,
	depth: 0,
	degree: 0,
	centrality: 0,
	position: { x: 0, y: 0, z: 0 },
});

const nodes = [
	node("Alpha", "Alpha"),
	node("A mechanism", "Alpha", "Models", "recursive boundary framing and reversible constraint"),
	node("A outcome", "Alpha", "Effects", "recursive boundary framing changes interpretation"),
	node("A gap", "Alpha", "Effects", "interpretive transition and constraint"),
	node("Beta", "Beta"),
	node("B mechanism", "Beta", "Models", "recursive boundary framing and contextual constraint"),
];

const edge = (source: string, target: string): AtlasEdge => ({
	id: `${source}::${target}`,
	source,
	target,
	topic: source.startsWith("A") ? "Alpha" : "Beta",
	type: "declared",
});

const edges = [
	edge("Alpha", "A mechanism"),
	edge("A mechanism", "A outcome"),
	edge("Alpha", "A gap"),
	edge("A outcome", "A gap"),
	edge("Beta", "B mechanism"),
];

const roots = chooseRoots(nodes, edges);
assert.deepEqual(roots.get("Alpha"), ["Alpha"], "exact topic-title note is the organizing hub");
const depths = assignDepths(nodes, edges, roots);
assert.equal(depths.get("Alpha"), 0);
assert.equal(depths.get("A mechanism"), 1);
assert.equal(depths.get("A outcome"), 2);

const laidOutA = layOutAtlas(nodes.map((value) => ({ ...value, position: { ...value.position } })), edges);
const laidOutB = layOutAtlas(nodes.map((value) => ({ ...value, position: { ...value.position } })), edges);
assert.deepEqual(laidOutA.nodes.map((value) => value.position), laidOutB.nodes.map((value) => value.position), "layout is deterministic");

const selection = selectionFor({ nodes: laidOutA.nodes, edges }, "A outcome");
assert(selection.ancestorIds.has("Alpha"));
assert(selection.ancestorIds.has("A mechanism"));
assert(selection.directFoundationIds.has("A mechanism"));

const bridges = discoverBridges(nodes, 10);
assert(bridges.some((candidate) => candidate.source === "A mechanism" && candidate.target === "B mechanism"), "cross-topic shared language becomes a candidate bridge");
assert(bridges.every((candidate) => nodes.find((value) => value.id === candidate.source)?.topic !== nodes.find((value) => value.id === candidate.target)?.topic), "bridges never duplicate within-topic declared structure");

const voidNodes = [node("Root", "Void"), node("Left", "Void"), node("Right", "Void"), node("Middle 1", "Void"), node("Middle 2", "Void")];
const voidEdges = [edge("Left", "Middle 1"), edge("Right", "Middle 1"), edge("Left", "Middle 2"), edge("Right", "Middle 2")];
assert(discoverVoids(voidNodes, voidEdges).some((candidate) => [candidate.source, candidate.target].includes("Left") && [candidate.source, candidate.target].includes("Right")), "two shared neighbors surface a structural void");

console.log("atlas logic tests passed");
