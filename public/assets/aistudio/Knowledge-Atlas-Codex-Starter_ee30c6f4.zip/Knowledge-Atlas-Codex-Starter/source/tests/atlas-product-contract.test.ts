import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const read = (path: string): string => readFileSync(path, "utf8");

const entrypoint = read("esbuild.config.mjs");
const plugin = read("src/atlas-main.ts");
const view = read("src/atlas/view.ts");
const discovery = read("src/atlas/discovery.ts");
const types = read("src/atlas/types.ts");
const styles = read("styles.css");
const manifest = JSON.parse(read("manifest.json")) as { description?: string };

assert.match(entrypoint, /entryPoints:\s*\["src\/atlas-main\.ts"\]/, "the production bundle must keep the Personal Atlas entrypoint");
assert.doesNotMatch(plugin, /open-relation-studio|VIEW_TYPE_RELATION_STUDIO|from \"\.\/main\"/, "the production plugin must not expose a separate Studio or legacy app");
assert.match(plugin, /onLayoutReady\(\(\) => this\.removeRejectedViews\(\)\)/, "stale rejected views must be removed after workspace restoration");
assert.match(plugin, /leaf\.view instanceof PersonalAtlasView \? leaf\.view\.reload/, "workspace reloads must ignore stale or unknown view instances");
assert.doesNotMatch(styles, /elf-relation-studio|elf-relation-vector|elf-relation-stats/, "rejected Studio and scorecard styles must not return");

for (const label of ["Atlas", "Bridges", "Gaps", "Patterns"]) {
	assert(view.includes(`["${label.toLowerCase()}", "${label}"]`), `${label} must remain a lens on the Atlas`);
}
assert.match(view, /createEl\("aside", \{ cls: "elf-atlas-card"/, "insight must stay inside one bounded elucidation card");
assert.match(styles, /data-type="elf-personal-atlas"[\s\S]*?overflow:\s*hidden/, "the Atlas must remain a single-screen spatial surface");

const cognitiveSurface = [view, discovery, types].join("\n");
for (const forbidden of [
	"reviewPriority",
	"reviewVector",
	"groundingTier",
	"fastestCheck",
	"confidenceScore",
	"noveltyScore",
	"ambiguityScore",
	"leverageScore",
]) {
	assert(!cognitiveSurface.includes(forbidden), `${forbidden} must not enter the Personal Atlas model or UI`);
}

assert.match(manifest.description ?? "", /calm 3D atlas of your notes/i, "the installed product must describe the visual instrument");
assert.doesNotMatch(manifest.description ?? "", /confidence|score/i, "the installed product must not be framed as scoring software");

console.log("atlas product-contract tests passed");
