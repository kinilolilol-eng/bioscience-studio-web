# Paste this into Codex with the unzipped starter folder available

I want you to install and tailor the attached **Personal Knowledge Atlas** to my own Obsidian vault.

This package is a data-free distillation of a working production brain architecture. Treat `ARCHITECTURE.md` and `AGENTS.md` as the contract. Preserve the existing visual and interaction model: one calm 3D Atlas, stable spatial memory, compact topic controls, one bounded elucidation card, and the existing Atlas / Bridges / Gaps / Patterns lenses. This is an adaptation of the vault-facing layer, not a redesign.

## First: inspect before changing anything

1. Locate and confirm the exact target vault. Do not guess from adjacent vaults.
2. Read any existing vault-level `AGENTS.md` and the relevant Obsidian configuration.
3. Inspect the vault’s real folder structure and a representative set of actual notes. Do not infer the structure from filenames alone.
4. Read this starter’s `START HERE.md`, `ARCHITECTURE.md`, `AGENTS.md`, and `source/src/atlas/model.ts`.
5. Determine which of the following questions are still unresolved, then ask me one concise batch. Do not ask what the vault already answers:

   - What should this Atlas help me understand or think through?
   - Which folders or kinds of notes belong in it, and which must stay out?
   - What is one node in my system: a note, a section, a concept note, or something else?
   - What should define a topic or cluster in my workspace?
   - What should define a category or structural layer inside a topic?
   - Which authored signals count as declared relations: wikilinks only, selected properties, or another explicit convention?
   - Which possible bridges, gaps, recurring patterns, or paths would actually be useful to me?
   - Which visual or conceptual behaviors must never be introduced?

Wait for my answers if they materially change the inclusion rule or mapping.

## Then: state the adaptation contract

Before editing, give me a compact mapping with:

- target vault;
- included note scope;
- exclusions;
- node unit;
- topic rule;
- category rule;
- declared-connection rule;
- title and excerpt rule;
- any requested vocabulary;
- files you expect to change.

The default starter rule is `<topic>/Concept Graph/<optional category>/<note>.md`, with wikilinks as declared connections and the note’s own body as its explanation. Keep it when it fits; otherwise adapt only the model adapter to the existing vault rather than forcing a disruptive reorganization.

## Implementation rules

- Do not import any note content from the starter; it contains none.
- Do not rewrite, move, rename, mass-tag, or add metadata to my notes unless I explicitly approve that separate operation.
- Do not replace the spatial Atlas with a dashboard, list, table, feed, scorecard, or separate analysis studio.
- Do not add numerical confidence, novelty, ambiguity, leverage, quality, or priority scores.
- A declared edge comes from an authored signal. A possible edge must remain dashed, quiet, reversible, and described as a suggestion.
- Keep / Name / Not useful judgments stay local to the plugin ledger and do not edit notes.
- Preserve deterministic layout, small visual budgets, stable connection identities, one selected insight at a time, and the ability to return to the authored Atlas.
- Preserve the production renderer, layout, lenses, card behavior, review logic, and styles unless I explicitly request an architectural change after seeing the faithful version working.
- Use the real note bodies when validating behavior. Never ship my note text inside the plugin bundle or build artifacts.
- Do not overwrite an existing vault-level `AGENTS.md`. If a permanent Atlas instruction is useful, propose a minimal merge for approval.

## Build and verify

1. Work from `source/`.
2. Install dependencies without changing versions unnecessarily.
3. Run `npm run check`, `npm test`, and `npm run build`.
4. Install only `main.js`, `manifest.json`, `styles.css`, and `versions.json` into `<vault>/.obsidian/plugins/personal-knowledge-atlas/`.
5. Reload Obsidian and enable **Personal Knowledge Atlas**.
6. Open the live Atlas and verify:
   - it uses the intended notes and excludes everything else;
   - the default view is the calm full Atlas;
   - topics are readable and compact;
   - selection dims unrelated context and brightens lineage;
   - the bounded card opens the correct note and shows a useful excerpt;
   - Bridges, Gaps, and Patterns remain visual lenses over the same spatial map;
   - no scoreboards or extra studio surfaces appear;
   - the plugin contains no copied note text or vault path;
   - rebuilding the same input is deterministic.
7. Fix any issue you can safely reproduce. Do not stop after merely compiling.

## Handoff

Finish with:

- the exact installed plugin path;
- the inclusion and mapping rules now in force;
- the files changed;
- checks and live verification performed;
- any limitation that still requires my decision.

