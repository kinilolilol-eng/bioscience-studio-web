# Personal Knowledge Atlas — Codex Starter

This package is the transferable, data-free form of the working Personal Knowledge Atlas.

It contains the actual Obsidian plugin, the editable production source, the architecture contract, and a prompt that lets Codex adapt only the vault-facing layer to a new person’s workspace. It contains no notes, note excerpts, graph data, review history, vault settings, or machine-specific paths.

## Recommended handoff

1. Send this entire ZIP.
2. Unzip it anywhere.
3. Open `CODEX-SETUP-PROMPT.md`.
4. Paste that prompt into Codex and attach or point Codex to the unzipped folder.
5. Let Codex inspect the friend’s actual vault, ask the short tailoring questions, install the plugin, and verify it in Obsidian.

## Direct installation without tailoring

The compiled plugin is in `plugin/personal-knowledge-atlas/`.

Copy that folder to:

```text
<vault>/.obsidian/plugins/personal-knowledge-atlas/
```

Then reload Obsidian, enable **Personal Knowledge Atlas** under **Community plugins**, and run **Open Personal Knowledge Atlas** from the command palette.

The default adapter reads Markdown notes arranged as:

```text
<topic>/Concept Graph/<optional category>/<note>.md
```

- The folder immediately before `Concept Graph` is the topic.
- The first folder after `Concept Graph` is the category; notes directly inside it use `Concepts`.
- Wikilinks between included notes are declared connections.
- The note’s own heading and body provide the title and bounded explanation.
- No note is rewritten.

If the vault uses another structure, use the Codex prompt rather than reorganizing it blindly.

## Contents

- `plugin/personal-knowledge-atlas/` — ready-to-install production plugin.
- `source/` — editable TypeScript, styles, build configuration, and tests.
- `ARCHITECTURE.md` — the preserved cognitive and interaction contract.
- `CODEX-SETUP-PROMPT.md` — implementation and tailoring prompt.
- `AGENTS.md` — guardrails Codex should follow while adapting the package.
- `CHECKSUMS.txt` — hashes for verifying the delivered files.

