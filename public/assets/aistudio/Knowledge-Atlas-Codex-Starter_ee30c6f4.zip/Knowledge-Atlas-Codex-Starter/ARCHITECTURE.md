# Personal Knowledge Atlas — Distilled Architecture Contract

## Purpose

The Atlas is a local cognitive instrument for thinking with a large Markdown workspace at a higher structural layer. It is not a replacement editor and it does not impose a domain. The user’s notes remain authoritative.

It should make visible:

- meaningful relations between ideas;
- dependencies that are easy to miss while reading notes one at a time;
- possible bridges across distant clusters;
- linked transitions that remain hard to understand;
- abstract structures that recur in different topics;
- paths that make a difficult idea or cluster easier to enter.

## Permanent visual grammar

The production build has one spatial surface and four lenses. This package preserves that interface rather than creating a dashboard or a second application.

1. The 3D atlas remains the dominant surface.
2. The wider workspace stays visible as quiet context.
3. Selecting one node or connection dims unrelated structure.
4. The selected lineage becomes bright and legible.
5. One bounded elucidation card explains the current focus.
6. Topic controls remain compact and secondary.
7. Atlas, Bridges, Gaps, and Patterns are lenses over the same stable spatial model.
8. The user can always return to the calm authored map.
9. Every lens has a strict visual budget, preventing the graph from becoming a hairball.
10. There are no scoreboards, confidence percentages, rankings, feeds, or full-screen analysis panels.

## Authored model

The default vault adapter includes notes under a `Concept Graph` folder. The surrounding path supplies topic and category. Wikilinks between included notes become declared edges. The layout is deterministic: the same note set and links produce the same positions and candidate identities.

The adapter is intentionally isolated in `source/src/atlas/model.ts`. Codex may tailor that file to a different vault organization after inspecting the real workspace. The renderer, layout, lenses, card, and interaction grammar should remain unchanged unless the owner explicitly requests a new product direction.

## Relation states

The system keeps connection status categorical and visible:

- **Declared** — already present as a wikilink in the Markdown workspace.
- **Possible** — a quiet, dashed visual suggestion derived from wording, meaning, or graph structure.
- **Kept** — a possible connection the user wants to retain for thought.
- **Named** — a kept connection given the user’s own relation phrase.
- **Dismissed** — not useful in the current model; hidden from ordinary lenses but reversible in local history.

A suggestion is never presented as truth. It appears with a plain-language reason and an inspectable context, not a scalar score.

## Candidate discovery

The engine uses independent categorical cues:

- **Wording** — a bounded passage explicitly uses a relation phrase between known ideas.
- **Shared context** — two ideas appear together in one passage without a proven direction.
- **Distinctive shared meaning** — distant notes reuse unusually specific language or a formulation.
- **Parallel role** — ideas occupy a similar category or structural role in different topics.
- **Structural gap** — two notes share several neighbors but have no direct connection.
- **Recurring shape** — the same category sequence occurs across multiple topics.

Generic overlap is filtered. Cross-topic candidates are diversified across cluster pairs. Only a small bounded set is rendered at once.

## Four visual lenses

### Atlas

Shows declared connections. Selecting an idea traces what it builds on and what it opens next.

### Bridges

Shows a small set of violet dashed arcs between distant clusters. Selecting an arc opens one card with the two ideas, why the bridge appeared, and `Keep`, `Name`, or `Not useful` actions.

### Gaps

Shows amber dashed transitions where a declared connection lacks an explicit explanation, remains on the same structural layer, or is authored only in one direction. The lens asks whether an intermediate idea, direction, or explanation is missing.

### Patterns

Highlights category sequences that recur across multiple topics. The graph shows every occurrence in place while the card steps through individual instances.

## Ways through an idea

The node card can illuminate bounded paths such as `From foundations`, `Toward use`, and `Across to another cluster`. A path never hides an unclear jump merely to appear smooth.

## User judgment and local history

Keeping, naming, revising, dismissing, and restoring a possible connection never rewrites a note. Each action is appended to a local `atlas-ledger.jsonl` inside the plugin folder. The current Atlas is a reversible projection of that history. This starter contains no ledger.

## Implementation boundary

Preserve these production components unless the new owner explicitly changes the architecture:

- `renderer.ts` — Three.js scene, selection, focus, and lens rendering;
- `layout.ts` — deterministic spatial arrangement;
- `view.ts` — one-screen interface, controls, rails, and bounded card;
- `discovery.ts` — categorical candidate discovery and path construction;
- `review.ts` and `ledger.ts` — reversible user judgment;
- `styles.css` — the production visual system.

Tailoring should normally be confined to:

- which notes enter the Atlas;
- how a vault path becomes a topic and category;
- which note text becomes the title, excerpt, and analysis text;
- any vocabulary or exclusions explicitly requested by the owner.

