# Codex Instructions for This Starter

## Objective

Install and adapt the bundled Personal Knowledge Atlas to the owner’s real Obsidian vault while preserving the production architecture in `ARCHITECTURE.md`.

## Non-negotiable boundaries

- This is a distillation and conversion task, not permission to redesign the product.
- Do not import sample notes or content from another vault.
- Do not rewrite, rename, move, or mass-tag the owner’s notes unless they explicitly authorize it.
- Do not assume a subject area, note taxonomy, or workflow before inspecting the target vault.
- Do not turn the Atlas into a dashboard, table, feed, leaderboard, or full-screen control studio.
- Do not add scalar quality, confidence, novelty, ambiguity, leverage, or priority scores.
- Keep possible connections visually and conceptually distinct from declared connections.
- Keep one bounded card and the compact topic controls.
- Preserve deterministic layout and bounded visual budgets.
- Preserve the reversible local review ledger.

## Adaptation boundary

Prefer adapting `source/src/atlas/model.ts`, which is the vault-facing adapter. Change renderer, layout, view, discovery, review, or styles only when the owner explicitly asks for a change to the architecture itself.

## Working method

1. Identify the exact vault and read any existing vault-level `AGENTS.md` before acting.
2. Inspect the actual folder structure, Obsidian configuration, and a representative set of notes.
3. Ask only the unresolved tailoring questions in `CODEX-SETUP-PROMPT.md`.
4. State the proposed inclusion rule and path-to-topic/category mapping before implementing it.
5. Keep all edits inside this starter and the target plugin directory unless broader vault edits are explicitly approved.
6. Run the included checks and tests, build the production bundle, install it, reload Obsidian, and verify the live Atlas.
7. Report exactly what was changed, what was preserved, and which assumptions remain.

Use an available Obsidian CLI for live verification when possible. If it is unavailable, use direct filesystem checks and explain the limitation.

